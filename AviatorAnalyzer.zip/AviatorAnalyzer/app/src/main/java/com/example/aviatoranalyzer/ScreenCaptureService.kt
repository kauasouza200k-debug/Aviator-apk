package com.example.aviatoranalyzer

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Collections
import java.util.concurrent.Executors
import java.util.regex.Pattern

class ScreenCaptureService: Service(){
 companion object { private val h=Collections.synchronizedList(mutableListOf<Double>()); private var last:Double?=null; private var lastAt=0L; private const val GAP=1800L; private const val MAX=200; fun getHistory():List<Double>=synchronized(h){h.toList()}; fun clearHistory(){synchronized(h){h.clear()};last=null;lastAt=0} }
 private var projection:MediaProjection?=null; private var display:VirtualDisplay?=null; private var reader:ImageReader?=null; private val exec=Executors.newSingleThreadExecutor(); private val ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
 override fun onCreate(){super.onCreate(); val ch=NotificationChannel("ocr","OCR",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager::class.java).createNotificationChannel(ch);startForeground(7,NotificationCompat.Builder(this,"ocr").setContentTitle("Aviator Analyzer").setContentText("OCR ativo").setSmallIcon(android.R.drawable.ic_menu_view).build())}
 override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{val code=i?.getIntExtra("resultCode",Activity.RESULT_CANCELED);val data=i?.getParcelableExtra<Intent>("data");if(code==Activity.RESULT_OK&&data!=null)startCapture(code,data);return START_NOT_STICKY}
 private fun startCapture(code:Int,data:Intent){val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=m.getMediaProjection(code,data);val dm=resources.displayMetrics;val w=dm.widthPixels;val ht=dm.heightPixels;reader=ImageReader.newInstance(w,ht,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("AviatorOCR",w,ht,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null);reader?.setOnImageAvailableListener({r->r.acquireLatestImage()?.let{process(it)}},exec)}
 private fun process(im:Image){try{val b=toBitmap(im);im.close();if(b==null)return;ocr.process(InputImage.fromBitmap(b,0)).addOnSuccessListener{res->extract(res.text).forEach{register(it)}}}catch(e:Exception){e.printStackTrace()}}
 private fun register(v:Double){val now=System.currentTimeMillis();if(last!=null&&kotlin.math.abs(last!!-v)<0.001&&now-lastAt<GAP)return;synchronized(h){h.add(v);if(h.size>MAX)h.removeAt(0)};last=v;lastAt=now}
 private fun extract(t:String):List<Double>{val out=mutableListOf<Double>();val m=Pattern.compile("""(\\d+(?:[.,]\\d+)?)\\s*[xX]""").matcher(t);while(m.find()){m.group(1)?.replace(',','.')?.toDoubleOrNull()?.takeIf{it>=1&&it<=100000}?.let{out.add(it)}};return out}
 private fun toBitmap(im:Image):Bitmap?{val p=im.planes[0];val buf=p.buffer;val ps=p.pixelStride;val rs=p.rowStride;val pad=rs-ps*im.width;val bw=im.width+pad/ps;val b=Bitmap.createBitmap(bw,im.height,Bitmap.Config.ARGB_8888);b.copyPixelsFromBuffer(buf);return Bitmap.createBitmap(b,0,0,im.width,im.height)}
 override fun onDestroy(){display?.release();reader?.close();projection?.stop();ocr.close();exec.shutdown();super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
