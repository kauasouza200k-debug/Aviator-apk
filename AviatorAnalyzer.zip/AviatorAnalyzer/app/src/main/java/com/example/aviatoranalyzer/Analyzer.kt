package com.example.aviatoranalyzer

object Analyzer {
    fun report(v: List<Double>): String {
        if (v.size < 5) return "Resultados: ${v.size}\n\nAguardando pelo menos 5 resultados."
        val r = v.takeLast(20); val avg = r.average(); val low = r.count { it < 2.0 }; val mid = r.count { it in 2.0..2.999999 }; val high = r.count { it >= 3.0 }
        val seq = r.asReversed().takeWhile { it < 2.0 }.size
        val signal = when { seq >= 4 -> "POSSÍVEL CONDIÇÃO — ATENÇÃO"; high >= 3 -> "AGUARDAR"; avg >= 2.5 -> "AGUARDAR"; else -> "SEM SINAL" }
        return """RODADAS ANALISADAS: ${r.size}\n\nÚltimo: %.2fx\nMédia: %.2fx\n< 2x: %.1f%%\n2x–3x: %.1f%%\n≥ 3x: %.1f%%\nSequência atual <2x: $seq\n\nINDICADOR: $signal""".format(r.last(), avg, low * 100.0 / r.size, mid * 100.0 / r.size, high * 100.0 / r.size)
    }
}
