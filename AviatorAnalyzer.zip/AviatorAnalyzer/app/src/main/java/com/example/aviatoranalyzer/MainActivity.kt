package com.example.aviatoranalyzer

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    companion object { private const val CAPTURE = 1001 }
    private lateinit var status: TextView; private lateinit var analysis: TextView; private lateinit var history: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        status=findViewById(R.id.statusText); analysis=findViewById(R.id.analysisText); history=findViewById(R.id.historyText)
        findViewById<Button>(R.id.startButton).setOnClickListener { requestCapture() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopService(Intent(this, ScreenCaptureService::class.java)); status.text="Captura parada" }
        findViewById<Button>(R.id.clearButton).setOnClickListener { ScreenCaptureService.clearHistory(); render() }
        findViewById<Button>(R.id.selectButton).setOnClickListener { status.text="Região configurável na próxima etapa; OCR atual usa a tela inteira." }
    }
    private fun requestCapture() { val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(),CAPTURE) }
    override fun onActivityResult(req:Int, code:Int, data:Intent?) { super.onActivityResult(req,code,data); if(req==CAPTURE && code==RESULT_OK && data!=null){ val i=Intent(this,ScreenCaptureService::class.java).putExtra("resultCode",code).putExtra("data",data); startForegroundService(i); status.text="Captura ativa — OCR em execução" } }
    override fun onResume(){super.onResume();render()}
    private fun render(){ val v=ScreenCaptureService.getHistory(); history.text=if(v.isEmpty())"Nenhum resultado detectado" else v.takeLast(40).reversed().joinToString("  •  "){ "%.2fx".format(it)}; analysis.text=Analyzer.report(v) }
}
