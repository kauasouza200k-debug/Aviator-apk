# Aviator Analyzer V1

Projeto Android Studio em Kotlin.

Inclui:
- MediaProjection para captura de tela autorizada pelo Android
- OCR com Google ML Kit
- extração de multiplicadores no formato 1.23x / 1,23x
- filtro básico de duplicatas
- histórico de até 200 resultados
- painel estatístico

## Abrir
Abra a pasta no Android Studio e aguarde o Gradle sincronizar.

## Rodar
Use um aparelho Android com Android 7.0+ (API 24+). Instale o APK de debug pelo Android Studio.
Ao iniciar a captura, o Android solicitará autorização de captura de tela.

## Observação
O botão de seleção de região está reservado para a próxima implementação. A versão incluída usa OCR na tela inteira para manter o projeto compilável e simples.

O indicador é estatístico e não prevê nem garante o próximo resultado de um jogo de azar.
